module.exports = async (req, res) => {
  try {
    const { response } = req.body;
    if (!response) return res.status(400).json({ error: 'No response payload' });

    // Decode the base64 response
    const decoded = JSON.parse(Buffer.from(response, 'base64').toString('utf8'));
    const xVerify = req.headers['x-verify'];

    if (xVerify) {
      // Verify checksum
      const expectedChecksum = crypto
        .createHash('sha256')
        .update(response + CLIENT_SECRET)
        .digest('hex') + '###1';

      if (xVerify !== expectedChecksum) {
        console.warn('[CALLBACK] Checksum mismatch — possible tampering');
        return res.status(403).json({ error: 'Invalid checksum' });
      }
    }

    const txnId  = decoded.data?.merchantTransactionId;
    const status = decoded.data?.state;  // COMPLETED, FAILED, PENDING

    console.log(`[CALLBACK] Txn: ${txnId} | Status: ${status}`);

    if (status === 'COMPLETED') {
      // Payment verified — trigger confirmation email
      // In production: update DB, trigger email, etc.
      console.log(`[PAYMENT CONFIRMED] ${txnId}`);
    }

    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('callback error:', err);
    return res.status(500).json({ error: err.message });
  }
};