module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const { name, email, course, amount, batch, orderRef } = req.body;

    const emailHtml = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body { margin:0; padding:0; background:#f8f7ff; font-family:'Segoe UI',Helvetica,Arial,sans-serif; }
  .wrap { max-width:560px; margin:0 auto; padding:32px 16px; }
  .card { background:#fff; border-radius:20px; overflow:hidden; box-shadow:0 4px 24px rgba(79,70,229,0.12); }
  .header { background:linear-gradient(135deg,#1e1b4b,#4f46e5,#7c3aed); padding:40px 32px; text-align:center; }
  .logo-icon { display:inline-block; width:52px; height:52px; background:rgba(255,255,255,0.15); border-radius:14px; line-height:52px; font-size:24px; margin-bottom:12px; }
  .brand { color:#fff; font-size:22px; font-weight:800; margin:0; letter-spacing:-0.02em; }
  .body { padding:32px; }
  h2 { color:#0f0e2a; font-size:22px; margin:0 0 8px; }
  .sub { color:#7b79a8; font-size:14px; margin-bottom:24px; }
  .order-box { background:linear-gradient(135deg,rgba(79,70,229,0.06),rgba(124,58,237,0.06)); border:1px solid rgba(79,70,229,0.15); border-radius:14px; padding:18px 20px; margin-bottom:20px; }
  .ob-row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid rgba(79,70,229,0.08); font-size:14px; }
  .ob-row:last-child { border-bottom:none; }
  .ob-label { color:#7b79a8; }
  .ob-val { color:#0f0e2a; font-weight:600; }
  .next-steps { margin-bottom:24px; }
  .next-steps h3 { color:#0f0e2a; font-size:16px; margin:0 0 14px; }
  .step-row { display:flex; align-items:flex-start; gap:12px; margin-bottom:12px; }
  .step-num { min-width:26px; height:26px; background:linear-gradient(135deg,#4f46e5,#7c3aed); color:#fff; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700; flex-shrink:0; }
  .step-text { font-size:14px; color:#3d3a6b; line-height:1.5; padding-top:3px; }
  .cta-btn { display:block; text-align:center; background:linear-gradient(135deg,#4f46e5,#7c3aed); color:#fff; text-decoration:none; padding:14px 28px; border-radius:50px; font-weight:700; font-size:15px; margin:24px 0 16px; }
  .guarantee { text-align:center; font-size:12px; color:#7b79a8; margin-bottom:24px; }
  .footer { background:#f8f7ff; padding:20px 32px; text-align:center; font-size:12px; color:#a9a7cc; border-top:1px solid rgba(79,70,229,0.08); }
  .footer a { color:#4f46e5; text-decoration:none; }
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="header">
      <div class="logo-icon">🎓</div>
      <p class="brand">PMpathshala</p>
    </div>
    <div class="body">
      <h2>You're enrolled, ${name}! 🎉</h2>
      <p class="sub">Your payment is confirmed. Here's everything you need to know.</p>

      <div class="order-box">
        <div class="ob-row"><span class="ob-label">Course</span><span class="ob-val">${course}</span></div>
        <div class="ob-row"><span class="ob-label">Batch</span><span class="ob-val">${batch}</span></div>
        <div class="ob-row"><span class="ob-label">Amount Paid</span><span class="ob-val">${amount}</span></div>
        <div class="ob-row"><span class="ob-label">Order Reference</span><span class="ob-val">${orderRef}</span></div>
      </div>

      <div class="next-steps">
        <h3>What happens next?</h3>
        <div class="step-row">
          <div class="step-num">1</div>
          <div class="step-text"><strong>Within 24 hours:</strong> Bhawesh will send you the Zoom link and WhatsApp group invite.</div>
        </div>
        <div class="step-row">
          <div class="step-num">2</div>
          <div class="step-text"><strong>Before Session 1:</strong> Complete the pre-work doc that will be shared in the WhatsApp group.</div>
        </div>
        <div class="step-row">
          <div class="step-num">3</div>
          <div class="step-text"><strong>On your batch start date:</strong> Join Zoom 5 minutes early to settle in. All sessions are recorded.</div>
        </div>
      </div>

      <a href="https://wa.me/919667783900?text=Hi%20Bhawesh!%20I%20just%20enrolled%20in%20${encodeURIComponent(course)}%20(Ref:%20${orderRef})" class="cta-btn">💬 Message Bhawesh on WhatsApp</a>

      <p class="guarantee">🛡️ 15-day money-back guarantee — if you're not satisfied after your first 2 sessions, email us for a full refund.</p>
    </div>
    <div class="footer">
      Questions? Reply to this email or call <a href="tel:+919667783900">+91-9667783900</a><br><br>
      <a href="https://pmpathshala.com/terms.html">Terms</a> &nbsp;·&nbsp; <a href="https://pmpathshala.com/privacy.html">Privacy</a><br><br>
      PMpathshala · support@pmpathshala.com
    </div>
  </div>
</div>
</body>
</html>`;

    // Send via Resend (https://resend.com — free 3k emails/month)
    const resendResponse = await fetch('https://api.resend.com/emails', {
      method : 'POST',
      headers: {
        'Content-Type'  : 'application/json',
        'Authorization' : `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from    : `PMpathshala <${process.env.EMAIL_FROM || 'support@pmpathshala.com'}>`,
        to      : [email],
        subject : `🎓 You're enrolled in ${course} — PMpathshala`,
        html    : emailHtml,
      }),
    });

    if (!resendResponse.ok) {
      const errData = await resendResponse.json();
      console.error('Resend error:', errData);
      return res.status(502).json({ error: 'Email send failed', details: errData });
    }

    console.log(`[EMAIL SENT] Confirmation to ${email} for order ${orderRef}`);
    return res.status(200).json({ success: true, message: `Confirmation sent to ${email}` });

  } catch (err) {
    console.error('send-confirmation error:', err);
    return res.status(500).json({ error: err.message });
  }
};