// api/create-payment.js
// PhonePe Payment Gateway v2 (OAuth-based)
// Correct for merchant IDs starting with M2... (new merchant accounts)

function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Max-Age', '86400');
}

// ── Get OAuth access token ────────────────────────────────────────
async function getAccessToken(clientId, clientSecret, env) {
  const tokenUrl = env === 'production'
    ? 'https://api.phonepe.com/apis/identity-manager/v1/oauth/token'
    : 'https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token';

  const res = await fetch(tokenUrl, {
    method  : 'POST',
    headers : { 'Content-Type': 'application/x-www-form-urlencoded' },
    body    : new URLSearchParams({
      client_id      : clientId,
      client_secret  : clientSecret,
      client_version : '1',
      grant_type     : 'client_credentials',
    }).toString(),
  });

  const text = await res.text();
  if (!res.ok) throw new Error(`OAuth failed (${res.status}): ${text}`);

  let data;
  try { data = JSON.parse(text); } catch { throw new Error('OAuth non-JSON: ' + text); }
  if (!data.access_token) throw new Error('No access_token: ' + JSON.stringify(data));
  return data.access_token;
}

// ── Main handler ──────────────────────────────────────────────────
module.exports = async function handler(req, res) {
  setCORS(res);
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST')   return res.status(405).json({ error: 'Method not allowed' });

  const MERCHANT_ID   = process.env.PHONEPE_MERCHANT_ID;
  const CLIENT_ID     = process.env.PHONEPE_CLIENT_ID;
  const CLIENT_SECRET = process.env.PHONEPE_CLIENT_SECRET;
  const SITE_URL      = (process.env.SITE_URL || 'https://www.pmpathshala.com').replace(/\/$/, '');
  const ENV           = process.env.PHONEPE_ENV || 'sandbox';

  if (!MERCHANT_ID || !CLIENT_ID || !CLIENT_SECRET) {
    return res.status(500).json({
      error   : 'Missing env variables on Vercel',
      missing : {
        PHONEPE_MERCHANT_ID  : !MERCHANT_ID,
        PHONEPE_CLIENT_ID    : !CLIENT_ID,
        PHONEPE_CLIENT_SECRET: !CLIENT_SECRET,
      }
    });
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = {}; } }
  const { amount, order_id, name, email, phone, course } = body || {};

  if (!amount || !order_id || !email) {
    return res.status(400).json({ error: 'Missing: amount, order_id, email' });
  }

  console.log(`[PhonePe] ${order_id} | ${email} | Rs${amount} | ${ENV}`);

  try {
    const accessToken = await getAccessToken(CLIENT_ID, CLIENT_SECRET, ENV);

    const pgUrl = ENV === 'production'
      ? 'https://api.phonepe.com/apis/pg/checkout/v2/pay'
      : 'https://api-preprod.phonepe.com/apis/pg-sandbox/checkout/v2/pay';

    const cleanPhone = phone ? phone.replace(/\D/g, '').slice(-10) : '';

    const payload = {
      merchantOrderId : order_id,
      amount          : Math.round(Number(amount) * 100),
      expireAfter     : 1200,
      metaInfo        : { udf1: name||'', udf2: email||'', udf3: course||'' },
      paymentFlow     : {
        type         : 'PG_CHECKOUT',
        message      : `PMpathshala – ${course || 'Enrollment'}`,
        merchantUrls : {
          redirectUrl: `${SITE_URL}/?payment=success&ref=${order_id}`,
        },
      },
    };

    if (cleanPhone.length === 10) payload.paymentFlow.mobileNumber = cleanPhone;

    const pgRes  = await fetch(pgUrl, {
      method  : 'POST',
      headers : {
        'Content-Type'  : 'application/json',
        'Authorization' : `O-Bearer ${accessToken}`,
        'X-Merchant-Id' : MERCHANT_ID,
      },
      body: JSON.stringify(payload),
    });

    const pgText = await pgRes.text();
    let pgData;
    try { pgData = JSON.parse(pgText); } catch { throw new Error('PhonePe non-JSON: ' + pgText); }

    console.log('[PhonePe response]', JSON.stringify(pgData));

    if (!pgRes.ok || !pgData.redirectUrl) {
      return res.status(502).json({
        error   : pgData.message || pgData.error || 'No redirectUrl from PhonePe',
        details : pgData,
      });
    }

    return res.status(200).json({ success: true, redirectUrl: pgData.redirectUrl, orderId: order_id });

  } catch (err) {
    console.error('[PhonePe error]', err.message);
    return res.status(500).json({ error: err.message });
  }
};